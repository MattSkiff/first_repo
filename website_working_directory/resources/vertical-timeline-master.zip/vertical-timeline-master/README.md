Vertical Timeline
=========

An easy to customize, responsive timeline.

[Article on CodyHouse](http://codyhouse.co/gem/vertical-timeline/)

[Demo](http://codyhouse.co/demo/vertical-timeline/index.html)
 
[Terms](http://codyhouse.co/terms/)

Icons: [Nucleo](https://nucleoapp.com)
